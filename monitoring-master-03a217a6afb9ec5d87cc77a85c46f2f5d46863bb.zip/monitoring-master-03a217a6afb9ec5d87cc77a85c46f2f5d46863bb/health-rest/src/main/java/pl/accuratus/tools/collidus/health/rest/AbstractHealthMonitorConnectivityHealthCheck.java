package pl.accuratus.tools.collidus.health.rest;

import com.google.common.base.Preconditions;
import pl.accuratus.tools.collidus.health.core.HealthCheck;
import pl.accuratus.tools.collidus.health.core.HealthCheckResult;
import pl.accuratus.tools.collidus.health.core.MonitoringService;

import javax.ws.rs.core.Response;

import static pl.accuratus.tools.collidus.health.core.HealthCheckResult.fail;
import static pl.accuratus.tools.collidus.health.core.HealthCheckResult.ok;


public class AbstractHealthMonitorConnectivityHealthCheck implements HealthCheck {

    private MonitoringService monitoringService;

    public AbstractHealthMonitorConnectivityHealthCheck(MonitoringService monitoringService) {
        Preconditions.checkArgument(monitoringService != null, "monitoringservice cannot be null");

        this.monitoringService = monitoringService;
    }

    @Override
    public HealthCheckResult run() {
        Response response = monitoringService.getHealthCheck();
        response.bufferEntity();

        try {
            if (isSuccessfulResponseStatus(response)) {
                return deserializeSuccessfulResult(response);
            }
            return tryDeserializeSuccessfulResult(response);
        } catch (Exception e) {
            if (isSuccessfulResponseStatus(response)) {
                return ok(response.readEntity(String.class));
            } else {
                return fail(e);
            }
        }
    }

    private boolean isSuccessfulResponseStatus(Response response) {
        return response.getStatusInfo().getFamily().equals(Response.Status.Family.SUCCESSFUL);
    }

    private HealthCheckResult tryDeserializeSuccessfulResult(Response healthCheck) {
        if (healthCheck.bufferEntity()) {
            return HealthCheckResult.warn(healthCheck.readEntity(HealthCheckResult.class));
        }
        return fail(healthCheck.readEntity(String.class));
    }

    private HealthCheckResult deserializeSuccessfulResult(Response healthCheck) {
        if (healthCheck.bufferEntity()) {
            HealthCheckResult details = healthCheck.readEntity(HealthCheckResult.class);
            return ok(details.getDetails());
        }
        return ok(healthCheck.readEntity(String.class));
    }
}
