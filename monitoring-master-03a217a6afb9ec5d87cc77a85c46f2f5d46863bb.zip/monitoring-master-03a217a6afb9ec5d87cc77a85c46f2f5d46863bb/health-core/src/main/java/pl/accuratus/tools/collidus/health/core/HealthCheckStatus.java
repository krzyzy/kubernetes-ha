package pl.accuratus.tools.collidus.health.core;

import java.util.Set;

public enum HealthCheckStatus {

    OK,
    WARN,
    FAIL;

    public static HealthCheckStatus and(Set<HealthCheckStatus> collect) {
        return collect.contains(FAIL)
                ? FAIL
                : (collect.contains(WARN) ? WARN : OK);
    }
}
