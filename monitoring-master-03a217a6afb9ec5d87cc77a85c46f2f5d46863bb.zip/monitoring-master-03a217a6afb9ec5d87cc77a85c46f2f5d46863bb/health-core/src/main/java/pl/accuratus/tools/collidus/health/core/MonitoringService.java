package pl.accuratus.tools.collidus.health.core;

import javax.ws.rs.GET;
import javax.ws.rs.HEAD;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/healthmonitor")
public interface MonitoringService {

    @GET
    @Produces("application/json")
    Response getHealthCheck();

    @HEAD
    @Produces("application/json")
    Response headHealthCheck();

}
