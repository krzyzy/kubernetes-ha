package pl.accuratus.tools.collidus.health.core.execution;

import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.accuratus.tools.collidus.health.core.*;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkState;
import static java.util.stream.Collectors.toSet;
import static pl.accuratus.tools.collidus.health.core.execution.ConcurrentTimeoutSupportHealthCheckExecutor.getSchedule;
import static pl.accuratus.tools.collidus.health.core.HealthCheckStatus.and;


public class CombinedBackgroundHealthCheck {

    private static final Logger LOGGER = LoggerFactory.getLogger(CombinedBackgroundHealthCheck.class);

    private final Map<HealthCheck, LocalDateTime> nextExecutions = Maps.newLinkedHashMap();
    private final Map<HealthCheck, CompletableFuture<HealthCheckResult>> healthChecks = Maps.newLinkedHashMap();
    private final HealthCheckExecutor healthCheckExecutor;
    private final ScheduledExecutorService scheduler;
    private final DateTimeProvider dateTimeProvider;

    private ScheduledFuture<?> scheduledFuture;

    public CombinedBackgroundHealthCheck(
            Collection<HealthCheck> healthChecks,
            HealthCheckExecutor healthCheckExecutor,
            ScheduledExecutorService scheduler,
            DateTimeProvider dateTimeProvider
    ) {
        this.healthCheckExecutor = healthCheckExecutor;
        this.scheduler = scheduler;
        this.dateTimeProvider = dateTimeProvider;

        LocalDateTime now = dateTimeProvider.now();
        for (HealthCheck hc : healthChecks) {
            HealthCheckSchedule healthCheckSchedule = getSchedule(hc);
            LOGGER.info(format(
                    "registering healthcheck '%s' with following configuration: {timeout: %s, interval: %s, impact: %s}",
                    hc.getClass().getSimpleName(),
                    healthCheckSchedule.timeoutInMillis(),
                    healthCheckSchedule.intervalInMillis(),
                    healthCheckSchedule.failureSeverity().name()
            ));
            this.nextExecutions.put(hc, now);
            this.healthChecks.put(hc, new CompletableFuture<>());
        }
    }

    @PostConstruct
    public void start() {
        LOGGER.info("Start healtchecking in the background ");
        checkState(scheduledFuture == null, "Already started. ");
        scheduledFuture = this.scheduler.scheduleWithFixedDelay(
                this::runExpiredChecks,
                0,
                500,
                TimeUnit.MILLISECONDS
        );
    }

    @PreDestroy
    public void stop() {
        LOGGER.info("Stop healtchecking in the background ");
        try {
            scheduledFuture.cancel(true);
        } catch (Exception e) {
            LOGGER.warn("unexpected exception while stopping healthchecks", e);
        }
    }

    private void runExpiredChecks() {
        List<HealthCheck> expiredChecks = findExpiredChecks();
        expiredChecks.forEach(hc -> nextExecutions.put(hc, dateTimeProvider.now().plus(getSchedule(hc).intervalInMillis(), ChronoUnit.MILLIS)));
        runChecks(expiredChecks);
    }

    private void runChecks(List<HealthCheck> checks) {
        LOGGER.debug("run checks: " + Joiner.on(",").join(checks.stream().map(healthCheck -> healthCheck.getClass().getSimpleName()).collect(Collectors.toList())));

        healthCheckExecutor
                .run(checks)
                .entrySet()
                .forEach(entry -> entry.getValue().thenAccept(result -> healthChecks.get(entry.getKey()).obtrudeValue(result)));
    }

    private List<HealthCheck> findExpiredChecks() {
        return nextExecutions.entrySet().stream()
                .filter(entry -> entry.getValue().isBefore(dateTimeProvider.now()))
                .map(entry -> entry.getKey())
                .collect(Collectors.toList());
    }

    public HealthCheckResult getResult() {
        Map<String, HealthCheckResult> healthChecks = Maps.newHashMap();
        this.healthChecks.entrySet().forEach(entry -> {
            try {
                healthChecks.put(entry.getKey().getClass().getSimpleName(), entry.getValue().get());
            } catch (Exception e) {
                throw new IllegalStateException("Unexpected exception while get healthcheck result from CompletableFuture", e);
            }
        });

        return new HealthCheckResult(
                and(
                        healthChecks.values().stream()
                                .map(HealthCheckResult::getStatus)
                                .collect(toSet())
                ),
                healthChecks
        );
    }

    /**
     * Created by tomasz on 07.06.16.
     */
    public interface DateTimeProvider {

        LocalDateTime now();

    }
}
