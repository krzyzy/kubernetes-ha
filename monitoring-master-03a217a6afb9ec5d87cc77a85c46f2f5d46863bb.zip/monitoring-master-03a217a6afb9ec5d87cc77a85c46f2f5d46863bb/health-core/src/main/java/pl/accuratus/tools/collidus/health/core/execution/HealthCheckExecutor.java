package pl.accuratus.tools.collidus.health.core.execution;

import pl.accuratus.tools.collidus.health.core.HealthCheck;
import pl.accuratus.tools.collidus.health.core.HealthCheckResult;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public interface HealthCheckExecutor {

    Map<HealthCheck, CompletableFuture<HealthCheckResult>> run(List<HealthCheck> checks);

    CompletableFuture<HealthCheckResult> run(HealthCheck hc);
}
