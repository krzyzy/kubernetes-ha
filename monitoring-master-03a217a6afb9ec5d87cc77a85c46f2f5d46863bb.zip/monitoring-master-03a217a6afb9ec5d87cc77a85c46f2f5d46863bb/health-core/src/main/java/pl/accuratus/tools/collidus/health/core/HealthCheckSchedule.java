package pl.accuratus.tools.collidus.health.core;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface HealthCheckSchedule {

    int intervalInMillis();

    int timeoutInMillis();

}
