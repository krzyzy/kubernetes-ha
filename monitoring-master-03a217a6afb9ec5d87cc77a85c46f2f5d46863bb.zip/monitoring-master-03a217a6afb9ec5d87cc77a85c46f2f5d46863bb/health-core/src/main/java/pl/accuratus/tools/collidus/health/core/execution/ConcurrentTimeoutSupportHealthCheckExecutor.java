package pl.accuratus.tools.collidus.health.core.execution;

import com.google.common.base.MoreObjects;
import com.google.common.collect.HashMultiset;
import com.google.common.collect.Multiset;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pl.accuratus.tools.collidus.health.core.*;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.lang.String.format;
import static java.util.concurrent.CompletableFuture.supplyAsync;
import static pl.accuratus.tools.collidus.health.core.HealthCheckStatus.*;

public class ConcurrentTimeoutSupportHealthCheckExecutor implements HealthCheckExecutor {

    private static final Logger LOGGER = LoggerFactory.getLogger(CombinedBackgroundHealthCheck.class);

    public static final HealthCheckSchedule DEFAULT_HEALTHCHECK_SCHEDULE = new HealthCheckSchedule() {

        @Override
        public int intervalInMillis() {
            return 5000;
        }

        @Override
        public int timeoutInMillis() {
            return 2000;
        }

        @Override
        public Class<? extends Annotation> annotationType() {
            return HealthCheckSchedule.class;
        }

    };

    public static final HealthCheckImpact DEFAULT_HEALTHCHECK_IMPACT = new HealthCheckImpact() {

        @Override
        public HealthCheckStatus impact() {
            return FAIL;
        }

        @Override
        public int allowedFailures() {
            return 3;
        }

        @Override
        public Class<? extends Annotation> annotationType() {
            return HealthCheckImpact.class;
        }

    };

    private final Multiset<HealthCheck> failedExecutions = HashMultiset.create();

    private final ScheduledExecutorService scheduler;
    private final HealthCheckExecutionHandler healthCheckExecutionHandler;

    public ConcurrentTimeoutSupportHealthCheckExecutor(
            ScheduledExecutorService scheduler
    ) {
        this(scheduler, HealthCheckExecutionHandler.NOOP);
    }

    public ConcurrentTimeoutSupportHealthCheckExecutor(
            ScheduledExecutorService scheduler,
            HealthCheckExecutionHandler healthCheckExecutionHandler
    ) {
        this.scheduler = scheduler;
        this.healthCheckExecutionHandler = healthCheckExecutionHandler;
    }

    @Override
    public Map<HealthCheck, CompletableFuture<HealthCheckResult>> run(List<HealthCheck> checks) {
        return checks.stream().collect(Collectors.toMap(
                    Function.identity(),
                    hc -> run(hc)
            ));
    }

    @Override
    public CompletableFuture<HealthCheckResult> run(HealthCheck hc) {
        HealthCheckSchedule config = getSchedule(hc);
        final long start = System.nanoTime();
        return runInBackground(hc, config.timeoutInMillis())
                .handle((result, throwable) -> throwableToResult(throwable, config.failureSeverity(), result))
                .thenApply(result -> log(hc, start, result))
                .thenApply(result -> squashFailures(hc, config, result));
    }

    private HealthCheckResult log(HealthCheck healthCheck, long start, HealthCheckResult healthCheckResult) {
        try {
            healthCheckExecutionHandler.onHealthCheckExecuted(
                    healthCheck.getClass().getSimpleName(),
                    healthCheckResult,
                    (System.nanoTime() - start) / 1000000
            );
        } catch (Exception e) {
            LOGGER.warn("Unexpected exception while invoking healtchcheckexecutionhandler", e);
        }
        return healthCheckResult;
    }

    private CompletableFuture<HealthCheckResult> runInBackground(HealthCheck healthCheck, int timeoutInMilis) {
        return supplyAsync(() -> healthCheck.run()).applyToEither(
                        failAfter(timeoutInMilis, format("Timeout '%s' after %s millis", healthCheck.getClass().getSimpleName(), timeoutInMilis)),
                        Function.identity()
                );
    }

    private HealthCheckResult throwableToResult(Throwable throwable, HealthCheckStatus failureSeverity, HealthCheckResult defaultResult) {
        return throwable != null ? new HealthCheckResult(failureSeverity, throwable) : defaultResult;
    }

    private HealthCheckResult squashFailures(HealthCheck healthCheck, HealthCheckSchedule schedule, HealthCheckResult healthCheckResult) {
        if (FAIL.equals(healthCheckResult.getStatus())) {
            failedExecutions.add(healthCheck);

            if (failedExecutions.count(healthCheck) > schedule.allowedFailures()) {
                return new HealthCheckResult(
                        schedule.failureSeverity(),
                        new FailureDetails(
                                format("Allowed failures (%s) exceeded", schedule.allowedFailures()),
                                healthCheckResult.getDetails()
                        )
                );
            } else {
                return new HealthCheckResult(
                        WARN,
                        new FailureDetails(
                                format("Allowed failures (%s) not exceeded yet: %s", schedule.allowedFailures(), failedExecutions.count(healthCheck)),
                                healthCheckResult.getDetails()
                        )
                );
            }
        } else {
            failedExecutions.remove(healthCheck, failedExecutions.count(healthCheck));
        }
        return healthCheckResult;
    }


    private <T> CompletableFuture<T> failAfter(int durationInMilis, String message) {
        final CompletableFuture<T> promise = new CompletableFuture<>();
        scheduler.schedule(() -> promise.completeExceptionally(new TimeoutException(message)), durationInMilis, TimeUnit.MILLISECONDS);
        return promise;
    }

    public static  HealthCheckSchedule getSchedule(HealthCheck healthChecks) {
        return MoreObjects.firstNonNull(
                healthChecks.getClass().getAnnotation(HealthCheckSchedule.class),
                DEFAULT_HEALTHCHECK_SCHEDULE
        );
    }

    /**
     * Created by tomasz on 06.06.16.
     */
    public static class FailureDetails {

        private final String message;
        private final Object details;

        public FailureDetails(String message, Object details) {
            this.message = message;
            this.details = details;
        }

        public String getMessage() {
            return message;
        }

        public Object getDetails() {
            return details;
        }

        @Override
        public String toString() {
            return "FailureDetails{" +
                    "message='" + message + '\'' +
                    ", details=" + details +
                    '}';
        }
    }
}
