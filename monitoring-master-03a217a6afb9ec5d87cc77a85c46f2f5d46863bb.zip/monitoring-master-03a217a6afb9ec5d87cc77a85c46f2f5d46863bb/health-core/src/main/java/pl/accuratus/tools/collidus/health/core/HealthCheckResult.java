package pl.accuratus.tools.collidus.health.core;

import com.google.common.base.Throwables;

public class HealthCheckResult {

    private HealthCheckStatus status;

    private Object details;

    public HealthCheckResult() {
    }

    public HealthCheckResult(HealthCheckStatus status, Throwable details) {
        this.status = status;
        this.details = Throwables.getStackTraceAsString(details);
    }

    public HealthCheckResult(HealthCheckStatus status, Throwable details, String message) {
        this.status = status;
        this.details = message+"\n"+Throwables.getStackTraceAsString(details);
    }


    public HealthCheckResult(HealthCheckStatus status, Object details) {
        this.status = status;
        this.details = details;
    }

    public HealthCheckResult(HealthCheckStatus status) {
        this.status = status;
    }

    public HealthCheckStatus getStatus() {
        return status;
    }

    public Object getDetails() {
        return details;
    }

    public static HealthCheckResult ok() {
        return new HealthCheckResult(HealthCheckStatus.OK);
    }

    public static HealthCheckResult fail(Exception e) {
        return new HealthCheckResult(HealthCheckStatus.FAIL, e);
    }

    public static HealthCheckResult fail(Object details) {
        return new HealthCheckResult(HealthCheckStatus.FAIL, details);
    }

    public static HealthCheckResult ok(Object details) {
        return new HealthCheckResult(HealthCheckStatus.OK, details);
    }

    public static HealthCheckResult warn(Object details) {
        return new HealthCheckResult(HealthCheckStatus.WARN, details);
    }

    public static HealthCheckResult warn(Throwable e, String message) {
        return new HealthCheckResult(HealthCheckStatus.WARN, e, message);
    }
}
