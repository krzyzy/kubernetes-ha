package pl.accuratus.tools.collidus.health.core.execution;

import pl.accuratus.tools.collidus.health.core.HealthCheckResult;

public interface HealthCheckExecutionHandler {

    HealthCheckExecutionHandler NOOP = (healthCheckName, healthCheckResult, duration) -> {
    };

    void onHealthCheckExecuted(String healthCheckName, HealthCheckResult healthCheckResult, long duration);

}
