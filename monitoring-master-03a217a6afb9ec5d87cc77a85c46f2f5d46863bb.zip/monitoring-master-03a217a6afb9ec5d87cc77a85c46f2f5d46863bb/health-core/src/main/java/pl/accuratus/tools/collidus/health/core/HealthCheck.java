package pl.accuratus.tools.collidus.health.core;

public interface HealthCheck {

    HealthCheckResult run() ;

}
